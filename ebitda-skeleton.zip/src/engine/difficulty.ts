import type { DifficultyPack, Mode } from './types'

export function modeToPack(mode: Mode, pack: DifficultyPack): DifficultyPack {
  // In skeleton, assume provided pack is correct for mode.
  return pack
}
